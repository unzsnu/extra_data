# To-do

A simple todo list app built in HTML, CSS and JavaScript.

## What's inside

- sketch file

  Wireframe_POC.sketch | two Artboard:

  - Wireframe with interaction

  - Wireframe COLOR, TAG, SEO details

- webapp

  - pug template for HTML

  - sass style for CSS

  - webpack build assets + devserver

### Install

```node
  npm install
```

#### build assets for prod and dev testing

```node
  npm run-script build
```

#### start webapp

```node
  npm run-script start
```

// remove comment to clean LocalStorage
localStorage.removeItem("todoList");
import './assets/css/style.sass';
var groupBy = require('lodash.groupby');

// general obj data
var data = (localStorage.getItem('todoList')) ? JSON.parse(localStorage.getItem('todoList')) : {
};
var c_type = '',
  c_filter = false,
  c_id = null,
  last_note_id = null;

// Remove and complete icons in SVG format
var removeSVG = '<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 22 22" xml:space="preserve"><rect class="noFill" width="22" height="22"/><g><g><path class="fill" d="M16.1,3.6h-1.9V3.3c0-1.3-1-2.3-2.3-2.3h-1.7C8.9,1,7.8,2,7.8,3.3v0.2H5.9c-1.3,0-2.3,1-2.3,2.3v1.3c0,0.5,0.4,0.9,0.9,1v10.5c0,1.3,1,2.3,2.3,2.3h8.5c1.3,0,2.3-1,2.3-2.3V8.2c0.5-0.1,0.9-0.5,0.9-1V5.9C18.4,4.6,17.4,3.6,16.1,3.6z M9.1,3.3c0-0.6,0.5-1.1,1.1-1.1h1.7c0.6,0,1.1,0.5,1.1,1.1v0.2H9.1V3.3z M16.3,18.7c0,0.6-0.5,1.1-1.1,1.1H6.7c-0.6,0-1.1-0.5-1.1-1.1V8.2h10.6V18.7z M17.2,7H4.8V5.9c0-0.6,0.5-1.1,1.1-1.1h10.2c0.6,0,1.1,0.5,1.1,1.1V7z"/></g><g><g><path class="fill" d="M11,18c-0.4,0-0.6-0.3-0.6-0.6v-6.8c0-0.4,0.3-0.6,0.6-0.6s0.6,0.3,0.6,0.6v6.8C11.6,17.7,11.4,18,11,18z"/></g><g><path class="fill" d="M8,18c-0.4,0-0.6-0.3-0.6-0.6v-6.8c0-0.4,0.3-0.6,0.6-0.6c0.4,0,0.6,0.3,0.6,0.6v6.8C8.7,17.7,8.4,18,8,18z"/></g><g><path class="fill" d="M14,18c-0.4,0-0.6-0.3-0.6-0.6v-6.8c0-0.4,0.3-0.6,0.6-0.6c0.4,0,0.6,0.3,0.6,0.6v6.8C14.6,17.7,14.3,18,14,18z"/></g></g></g></svg>';
var completeSVG = '<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 22 22" xml:space="preserve"><rect y="0" class="noFill" width="22" height="22"/><g><path class="fill" d="M9.7,14.4L9.7,14.4c-0.2,0-0.4-0.1-0.5-0.2l-2.7-2.7c-0.3-0.3-0.3-0.8,0-1.1s0.8-0.3,1.1,0l2.1,2.1l4.8-4.8c0.3-0.3,0.8-0.3,1.1,0s0.3,0.8,0,1.1l-5.3,5.3C10.1,14.3,9.9,14.4,9.7,14.4z"/></g></svg>';

// fetch data or retrieve from storage
// @type string : users | todos, @id number : id | null
function getData(type, id) {
  c_type = typeof type !== 'undefined' ? type : 'users';
  document.getElementById('p_' + c_type).classList.add('active');
  document.getElementById('list').innerHTML = '';
  c_id = typeof id !== 'undefined' && id !== null ? '/' + id : '';

// details fetch, even if data already present in generic list
  if(data[c_type + (id ? id : '')]){
    renderTodoList(data[c_type + (id ? id : '')]);
  } else{
    fetch('https://jsonplaceholder.typicode.com/' + c_type + c_id)
    .then(response => response.json())
    .then(json => data[c_type + (id ? id : '')] = json)
    .then(data => renderTodoList(data));
  }
}
// get data
getData('users', null);

// menu
var l_paging = document.querySelectorAll("nav li");
Array.from(l_paging).forEach(function (element, index) {
  element.addEventListener("click", function (e) {
    c_type = e.currentTarget.id.substring(2);
    if (!e.currentTarget.classList.contains("active")) {
      let last_active = document.querySelector("nav li.active");
      if (last_active) {
        last_active.classList.remove("active");
        last_active.removeAttribute("aria-current");
      }
    }
    if(c_type === 'users'){
      getData(c_type, null);
    } else {
      c_filter = null;
      l_filter[0].click();
    }
    let active = e.currentTarget;
    active.classList.add("active");
    active.setAttribute("aria-current", "true");
    return false;
  });
});

// filter todos | completed | per user
var l_filter = document.querySelectorAll("#filter li");
Array.from(l_filter).forEach(function (element, index) {
  element.addEventListener("click", function (e) {
    c_filter = e.currentTarget.dataset.filter;
    if (!e.currentTarget.classList.contains("active")) {
      let last_active = document.querySelector("#filter li.active");
      if (last_active) {
        last_active.classList.remove("active");
        last_active.removeAttribute("aria-current");
      }
    }
    let active = e.currentTarget;
    active.classList.add("active");
    active.setAttribute("aria-current", "true");
    getData(c_type, null);
    return false;
  });
});

// add new todo
// @value string : todo text
function addItem(value) {
  // incremental todo id
  last_note_id = last_note_id + 1;
  let newObj = {
    // fixed userId, mimic user logged
    userId: 10,
    id: (last_note_id),
    title: value,
    completed: false,
  };
  addItemToDOM(newObj, true);
  document.getElementById('item').value = '';

  data.todos.push(newObj); // update global obj with new todo
  data['todos'+last_note_id] = newObj; // mimic fetched detail
  dataObjectUpdated();
}
// join user info with todos data
function getMoreInfo(userId){
    // get info for matched id
    function getMoreInfoById(info) {
        if (info.id === userId) {
            return info;
        }
    }
    var info = data.users.find(getMoreInfoById, userId);
    return info.name;
}
// render json
// @json_data obj|array : filtered data obj, only todos | users | details
function renderTodoList(json_data) {
  // sort data if needed
  //json_data.sort(function(a, b){return b.id - a.id;});
  document.getElementById('addNote').style.display = c_type === 'todos' ? 'flex' : 'none';
  document.getElementById('list').classList = c_filter ? c_filter : '';
  // if todos filter is selected
  if (c_filter) {
    var cloneobj = json_data;
    // group todos by user - import from lodash fn
    let filtro = groupBy(cloneobj, c_filter);
    if (Object.keys(filtro).length > 0) {
      let root = document.getElementById('list');
      if (c_filter === 'userId') {
        for (let i = 1; i <= Object.keys(filtro).length; i++) {

          let item = document.createElement('li');
          let detailsDom = document.createElement('details');
          item.classList.add('group');
          detailsDom.innerHTML = '<summary><em>(#'+Object.keys(filtro[i]).length+')' + getMoreInfo(filtro[i][0].userId) + '</em></summary>';

          let subitem = document.createElement('ul');
          subitem.id = 'grp_' + filtro[i][0].userId;

          detailsDom.appendChild(subitem);
          item.appendChild(detailsDom);
          root.appendChild(item);
          for (let z = 0; z < filtro[i].length; z++) {
            let value = filtro[i][z];
            addItemToDOM(value, false);
          }

        }
      } else {
        for (let z = 0; z < filtro.true.length; z++) {
          let value = filtro.true[z];
          addItemToDOM(value, true);
        }
      }

    }
  } else {
    // no filter selected: all todos | users
    if (Array.isArray(json_data)) {
      if (!json_data.length) return;
      for (let i = 0; i < json_data.length; i++) {
        let value = json_data[i];
        addItemToDOM(value, true);
      }
      if (c_type === 'todos') {
        // store the last todo id inserted
        var max = json_data.length - 1;
        last_note_id = json_data[max].id;
      }
    } else {
      addItemToDOM(json_data, true);
    }
  }
  c_filter = false;
}

// update local storage
function dataObjectUpdated() {
  localStorage.setItem('todoList', JSON.stringify(data));
}

// Add new item to the todo list in DOM
// @single_json obj : single object todo | users
function addItemToDOM(single_json, node) {
  var listina = (node) ? document.getElementById('list') : document.getElementById('grp_' + single_json.userId);

  var item = document.createElement('li');
  var article = document.createElement('article');
  item.dataset.id = single_json.id;

  if (c_id) {
    // details todo | user
    article.classList.add('detail');
    if (c_type === 'users') {
      article.innerHTML = single_json.id + '<h2>' + single_json.name + '</h2>' +
        '<p><a href="mailto:' + single_json.email + '">email</a><br/>' +
        'Address: ' + single_json.address.street + ',' + single_json.address.suite + ',' + single_json.address.city + '<br/>' +
        'Company:' + single_json.company.name + '</br></p>';
    } else {
      article.innerHTML = '<span>[id:'+ single_json.id + ']</span><p>' + single_json.title + '</p><em>by '+getMoreInfo(single_json.userId)+'</em>';
    }
  } else {
    // list
    if (c_type === 'users') {
      article.innerHTML = '<span>[id:'+ single_json.id + ']</span><h3>' + single_json.name + '</h3><b>' + single_json.company.name + '</b>';
    } else {
      article.innerHTML = '<span>[id:'+ single_json.id + ']</span><p>' + single_json.title + '</p>'+(c_filter !== 'userId' ? '<em>by '+getMoreInfo(single_json.userId)+'</em>' : '');
    }
    // events: click single item from the list to show details
    article.addEventListener('click', function (e) {
      c_id = item.dataset.id;
      showDetail();
    });
  }
  item.appendChild(article);
  if (c_type === 'todos') {
    if (single_json.completed) {
      item.classList.add('completed');
    }
    var buttons = document.createElement('div');
    buttons.classList.add('buttons');

    var remove = document.createElement('button');
    remove.classList.add('remove');
    remove.innerHTML = removeSVG;

    // events: click for removing the item
    remove.addEventListener('click', removeItem);

    var complete = document.createElement('button');
    complete.classList.add('complete');
    complete.innerHTML = completeSVG;

    // events: click for completing the item
    complete.addEventListener('click', completeItem);

    buttons.appendChild(remove);
    buttons.appendChild(complete);
    item.appendChild(buttons);
  }
  listina.prepend(item);
}
// retrieve details single todo | user
function showDetail() {
  getData(c_type, c_id);
  return false;
}

// events: click to add todo
document.getElementById('add').addEventListener('click', function () {
  var value = document.getElementById('item').value;
  if (value) {
    addItem(value);
  }
});
// events: key enter to add todo
document.getElementById('item').addEventListener('keydown', function (e) {
  var value = this.value;
  if (e.code === 'Enter' && value) {
    addItem(value);
  }
});

// remove todo from DOM and data obj
function removeItem() {
  var item = this.parentNode.parentNode;
  var myitem_id = parseInt(item.dataset.id);
  let arrIndex = data.todos.findIndex((obj => obj.id === myitem_id));
  data.todos.splice(arrIndex, 1);
  item.parentNode.removeChild(item);
}
// complete todo from DOM and data obj
function completeItem() {
  var item = this.parentNode.parentNode;
  var myitem_id = parseInt(item.dataset.id);

  let arrIndex = data.todos.findIndex((obj => obj.id === myitem_id));

  if (item.classList.contains('completed')) {
   data.todos[arrIndex].completed = false;
   item.classList.remove('completed');

  } else {

    data.todos[arrIndex].completed = true;
    item.classList.add('completed');

  }
  dataObjectUpdated();

}
